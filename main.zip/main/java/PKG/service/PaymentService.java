package PKG.service;

public interface PaymentService {
    void processPayment();  // sau này có thể thêm tham số (giá, mã đơn, v.v.)
}