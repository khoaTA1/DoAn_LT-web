package PKG.model;

import lombok.Data;

@Data
public class inputCard {
	private long itemId;
	
	private int quantity;
}
