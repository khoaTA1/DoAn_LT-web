package PKG.model;

import lombok.Data;

@Data
public class paymentInfo {
	private double amount;
    private long userId;
}
