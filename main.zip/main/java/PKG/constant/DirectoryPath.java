package PKG.constant;

public class DirectoryPath {
	public static final String dir = "C:\\Users\\khoat\\Documents\\HOC\\LT_web\\save\\1a\\DoAn\\res\\";
}
